#!/bin/bash

# Nicky Webhook Quick Debug Script
# Verwendung: ./webhook-debug.sh [DOMAIN]
# Beispiel: ./webhook-debug.sh https://meinshop.de

DOMAIN=${1:-"http://localhost"}
WEBHOOK_URL="${DOMAIN}/?wc-api=wc_gateway_nicky"

echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║         Nicky Webhook Debug Script                           ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo ""
echo "Domain: $DOMAIN"
echo "Webhook URL: $WEBHOOK_URL"
echo ""

# Test 1: GET Request (should return 400)
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Test 1: GET Request (erwartet: 400 Bad Request)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Command: curl -sS -w '\\nHTTP Status: %{http_code}\\n' '$WEBHOOK_URL'"
echo ""
curl -sS -w '\nHTTP Status: %{http_code}\n' "$WEBHOOK_URL"
echo ""
echo "✓ Wenn Status 400 und 'missing_webhook_type' → Korrekt!"
echo "✗ Wenn Status 404 → WordPress erreicht Handler nicht!"
echo ""
read -p "Drücke Enter für nächsten Test..."

# Test 2: POST Request ohne Body (should return 400)
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Test 2: POST Request ohne Body (erwartet: 400 Bad Request)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Command: curl -sS -X POST -w '\\nHTTP Status: %{http_code}\\n' '$WEBHOOK_URL'"
echo ""
curl -sS -X POST -w '\nHTTP Status: %{http_code}\n' "$WEBHOOK_URL"
echo ""
echo "✓ Wenn Status 400 und 'missing_webhook_type' → Korrekt!"
echo "✗ Wenn Status 404 → WordPress erreicht Handler nicht!"
echo ""
read -p "Drücke Enter für nächsten Test..."

# Test 3: POST Request mit falschem WebHookType (should return 200 ignored)
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Test 3: POST mit falschem WebHookType (erwartet: 200 OK)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
JSON='{"WebHookType":"SomeOtherType"}'
echo "JSON: $JSON"
echo ""
curl -sS -X POST -H "Content-Type: application/json" -d "$JSON" -w '\nHTTP Status: %{http_code}\n' "$WEBHOOK_URL"
echo ""
echo "✓ Wenn Status 200 und 'ignored' → Korrekt!"
echo ""
read -p "Drücke Enter für nächsten Test..."

# Test 4: POST Request mit korrektem WebHookType aber ohne ItemId (should return 400)
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Test 4: POST mit WebHookType aber ohne ItemId (erwartet: 400)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
JSON='{"WebHookType":"PaymentRequest_StatusChanged"}'
echo "JSON: $JSON"
echo ""
curl -sS -X POST -H "Content-Type: application/json" -d "$JSON" -w '\nHTTP Status: %{http_code}\n' "$WEBHOOK_URL"
echo ""
echo "✓ Wenn Status 400 und 'missing_item_id' → Korrekt!"
echo ""
read -p "Drücke Enter für nächsten Test..."

# Test 5: POST Request mit vollständigen Daten (should return 404 order_not_found for test data)
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Test 5: POST mit vollständigen Test-Daten"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
JSON='{
  "WebHookType": "PaymentRequest_StatusChanged",
  "ItemId": "test-payment-request-id-12345",
  "Data": {
    "PreviousStatus": "Pending",
    "NewStatus": "Finished"
  }
}'
echo "JSON: $JSON"
echo ""
curl -sS -X POST -H "Content-Type: application/json" -d "$JSON" -w '\nHTTP Status: %{http_code}\n' "$WEBHOOK_URL"
echo ""
echo "✓ Wenn Status 404 oder 500 und 'order_not_found' → Handler funktioniert!"
echo "  (Order existiert nicht, das ist OK für Test-Daten)"
echo "✗ Wenn Status 404 ohne Body → WordPress erreicht Handler nicht!"
echo ""

# Summary
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Zusammenfassung"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Wenn ALLE Tests 400, 200 oder 404 MIT Text zurückgeben:"
echo "  → ✓ Webhook Handler funktioniert korrekt!"
echo ""
echo "Wenn irgendein Test 404 OHNE Text zurückgibt:"
echo "  → ✗ WordPress erreicht den Handler nicht"
echo "  → Lösung: Permalinks neu speichern in WordPress Admin"
echo ""
echo "Nächste Schritte:"
echo "  1. Führe test-webhook-endpoint.php im Browser aus"
echo "  2. Prüfe WordPress Logs: docker-compose logs -f wordpress | grep Nicky"
echo "  3. Erstelle eine Test-Bestellung im Shop"
echo "  4. Beobachte Logs während Zahlung"
echo ""
